<?php
/*
Plugin Name: Theme Custom Blocks
Plugin URI: https://github.com/FourColumnsMarketing/4C-Block-Library
Description: This is a dump of all custom blocks specific to this site.
Version: 0.0.1
Author: The Four Columns Team
Author URI: https://fourcolumns.net
License: GPLv2
*/

add_action('acf/init', 'init_custom_blocks');
function init_custom_blocks()
{
  // Check function exists.
  if (function_exists('acf_register_block_type')) {
    /*
    Example Function for ease of copy paste
	  acf_register_block_type([
		'name'        => 'contentblock',
		'title'       => __('Content Block'),
		'description' => __('The original content block. '),
    Use plugin_dir_path(__FILE__) to get relative path to plugin
		'render_template' => plugin_dir_path( __FILE__ ) . 'blocks/content-block/block.php',
		'icon'            => 'editor-alignleft',
		'keywords'        => ['content', 'image'],
    ]);
    */
  }
}